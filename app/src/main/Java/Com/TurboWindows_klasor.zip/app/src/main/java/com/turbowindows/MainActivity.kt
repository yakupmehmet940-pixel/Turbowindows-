package com.turbowindows

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var desktop: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDesktop()
    }

    private fun showDesktop() {
        desktop = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(18, 30, 52))
        }

        val title = TextView(this).apply {
            text = "TurboWindows"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        desktop.addView(title)

        val subtitle = TextView(this).apply {
            text = "Offline Desktop • Online Video Center"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        desktop.addView(subtitle)

        addButton("YouTube Video Center") {
            openUrl("https://www.youtube.com/")
        }

        addButton("Video dosyalarımı aç") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "video/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            try {
                startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "Video seçici açılamadı.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun addButton(label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(0, 12, 0, 0)
        desktop.addView(button, params)
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "Tarayıcı açılamadı.", Toast.LENGTH_LONG).show()
        }
    }
}
